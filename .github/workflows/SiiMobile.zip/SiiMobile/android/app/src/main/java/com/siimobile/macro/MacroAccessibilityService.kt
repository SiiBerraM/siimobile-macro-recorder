package com.siimobile.macro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent

/**
 * Replays strokes on top of ANY app using dispatchGesture (needs the user to enable
 * the service in Settings > Accessibility). Enforces the mandatory run-time limit
 * natively, so the countdown keeps working when the app UI is in the background.
 */
class MacroAccessibilityService : AccessibilityService() {

    interface PlaybackListener {
        fun onTick(remainingMs: Long)
        fun onFinished(reason: String) // completed | time_limit | user_stop | interrupted | service_disabled
    }

    companion object {
        @Volatile var instance: MacroAccessibilityService? = null
    }

    var listener: PlaybackListener? = null
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var running = false

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* not used */ }
    override fun onInterrupt() { stopPlayback("interrupted") }
    override fun onUnbind(intent: Intent?): Boolean {
        stopPlayback("service_disabled")
        instance = null
        return super.onUnbind(intent)
    }

    /** Dispatches a single stroke (tap or swipe) on the real screen. */
    fun dispatchStroke(stroke: Stroke, onDone: (() -> Unit)? = null) {
        val pts = stroke.points
        if (pts.isEmpty()) { onDone?.invoke(); return }
        val path = Path().apply {
            moveTo(pts[0].first, pts[0].second)
            for (i in 1 until pts.size) lineTo(pts[i].first, pts[i].second)
        }
        val dur = stroke.durationMs.coerceIn(1L, GestureDescription.getMaxGestureDuration())
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, dur))
            .build()
        val ok = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { onDone?.invoke() }
            override fun onCancelled(g: GestureDescription?) { onDone?.invoke() }
        }, null)
        if (!ok) onDone?.invoke()
    }

    /**
     * @param loops       0 = repeat until the time limit ends
     * @param intervalMs  pause between two loops (custom timer)
     * @param runLimitMs  MANDATORY max run time; playback always stops when it expires
     */
    fun startPlayback(strokes: List<Stroke>, loops: Int, intervalMs: Long, runLimitMs: Long) {
        if (strokes.isEmpty() || runLimitMs <= 0) return
        stopPlayback(null)
        running = true

        val deadline = SystemClock.elapsedRealtime() + runLimitMs
        val loopLengthMs = strokes.maxOf { it.startMs + it.durationMs }
        var loopIndex = 0
        fun remaining() = deadline - SystemClock.elapsedRealtime()

        // 1-second countdown ticker
        val ticker = object : Runnable {
            override fun run() {
                if (!running) return
                val r = remaining()
                if (r <= 0) { stopPlayback("time_limit"); return }
                listener?.onTick(r)
                handler.postDelayed(this, 1000)
            }
        }
        handler.post(ticker)

        fun runLoop() {
            if (!running) return
            strokes.forEach { s ->
                handler.postDelayed({
                    if (running && remaining() > 0) dispatchStroke(s)
                }, s.startMs)
            }
            handler.postDelayed({
                if (!running) return@postDelayed
                loopIndex++
                if (loops != 0 && loopIndex >= loops) stopPlayback("completed")
                else handler.postDelayed({ runLoop() }, intervalMs)
            }, loopLengthMs + 50)
        }
        runLoop()
    }

    fun stopPlayback(reason: String?) {
        val wasRunning = running
        running = false
        handler.removeCallbacksAndMessages(null)
        if (reason != null && wasRunning) listener?.onFinished(reason)
    }
}
