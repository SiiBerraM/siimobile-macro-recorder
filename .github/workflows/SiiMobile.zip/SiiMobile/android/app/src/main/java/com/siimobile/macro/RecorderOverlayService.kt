package com.siimobile.macro

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView

/**
 * Full-screen transparent overlay (gold-tinted) that captures touches while recording.
 * Each finished stroke is also re-dispatched live through the accessibility service,
 * so the app underneath still reacts and you can navigate while recording.
 * A floating gold "Stop" pill shows the remaining time and ends the recording.
 */
class RecorderOverlayService : Service() {

    companion object {
        const val EXTRA_LIMIT_MS = "limitMs"
        /** Called when recording ends (stop button, time limit or service stopped). */
        @Volatile var onFinished: ((List<Stroke>) -> Unit)? = null
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var capture: CaptureView
    private lateinit var capLp: WindowManager.LayoutParams
    private lateinit var pill: TextView
    private val strokes = mutableListOf<Stroke>()
    private var recordStart = 0L
    private var deadline = 0L
    private var delivered = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val limit = intent?.getLongExtra(EXTRA_LIMIT_MS, 0L) ?: 0L
        NotificationHelper.startForeground(this, "Recording…")
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        recordStart = SystemClock.elapsedRealtime()
        deadline = recordStart + limit
        addCaptureOverlay()
        addStopPill()
        handler.post(tick)
        return START_NOT_STICKY
    }

    private val tick = object : Runnable {
        override fun run() {
            val r = deadline - SystemClock.elapsedRealtime()
            if (r <= 0) { stopSelf(); return }
            pill.text = "■  Stop  " + NotificationHelper.formatTime(r)
            MacroBridgeModule.emit("MacroTick", mapOf("remainingMs" to r.toDouble(), "mode" to "recording"))
            handler.postDelayed(this, 1000)
        }
    }

    private fun addCaptureOverlay() {
        capture = CaptureView(this).apply { setBackgroundColor(0x1AD4AF37) } // faint gold tint
        capLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(capture, capLp)
    }

    private fun addStopPill() {
        pill = TextView(this).apply {
            text = "■  Stop"
            setTextColor(Color.BLACK)
            textSize = 15f
            setPadding(44, 22, 44, 22)
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0xFFF3DC8A.toInt(), 0xFFD4AF37.toInt(), 0xFF8C6D1F.toInt())
            ).apply { cornerRadius = 100f }
            setOnClickListener { stopSelf() }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 24; y = 120 }
        wm.addView(pill, lp) // added last => above the capture layer
    }

    private fun setTouchable(touchable: Boolean) {
        capLp.flags = if (touchable) capLp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        else capLp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        if (capture.isAttachedToWindow) wm.updateViewLayout(capture, capLp)
    }

    private fun onStrokeFinished(stroke: Stroke) {
        strokes.add(stroke)
        val svc = MacroAccessibilityService.instance ?: return
        setTouchable(false) // let the injected gesture reach the app below
        svc.dispatchStroke(stroke) { handler.post { setTouchable(true) } }
    }

    private inner class CaptureView(ctx: Context) : View(ctx) {
        private val pts = mutableListOf<Pair<Float, Float>>()
        private var downAt = 0L

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    pts.clear()
                    downAt = SystemClock.elapsedRealtime()
                    pts.add(e.rawX to e.rawY)
                }
                MotionEvent.ACTION_MOVE -> pts.add(e.rawX to e.rawY)
                MotionEvent.ACTION_UP -> {
                    pts.add(e.rawX to e.rawY)
                    val now = SystemClock.elapsedRealtime()
                    onStrokeFinished(Stroke(downAt - recordStart, (now - downAt).coerceAtLeast(1), thin(pts)))
                }
                MotionEvent.ACTION_CANCEL -> pts.clear()
            }
            return true
        }

        /** A tap keeps one point; swipes are reduced to at most ~40 points. */
        private fun thin(src: List<Pair<Float, Float>>): List<Pair<Float, Float>> {
            val moved = src.size > 1 &&
                (Math.abs(src.last().first - src.first().first) > 12 || Math.abs(src.last().second - src.first().second) > 12)
            if (!moved) return listOf(src.first())
            val step = Math.max(1, src.size / 40)
            return src.filterIndexed { i, _ -> i % step == 0 || i == src.lastIndex }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        runCatching { wm.removeView(capture) }
        runCatching { wm.removeView(pill) }
        if (!delivered) {
            delivered = true
            onFinished?.invoke(strokes.toList())
        }
        super.onDestroy()
    }
}
