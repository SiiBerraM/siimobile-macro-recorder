package com.siimobile.macro

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.facebook.react.ReactPackage
import com.facebook.react.bridge.*
import com.facebook.react.modules.core.DeviceEventManagerModule
import com.facebook.react.uimanager.ViewManager

/** JS <-> native bridge. Exposed to JS as NativeModules.MacroNative. */
class MacroBridgeModule(private val rc: ReactApplicationContext) : ReactContextBaseJavaModule(rc) {

    init { reactCtx = rc }
    override fun getName() = "MacroNative"

    companion object {
        @Volatile var reactCtx: ReactApplicationContext? = null

        fun emit(event: String, data: Map<String, Any?> = emptyMap()) {
            val map = Arguments.createMap()
            data.forEach { (k, v) ->
                when (v) {
                    is String -> map.putString(k, v)
                    is Double -> map.putDouble(k, v)
                    is Int -> map.putInt(k, v)
                    else -> {}
                }
            }
            reactCtx?.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)?.emit(event, map)
        }
    }

    // ---- permissions -------------------------------------------------------
    @ReactMethod fun isAccessibilityEnabled(p: Promise) = p.resolve(MacroAccessibilityService.instance != null)
    @ReactMethod fun canDrawOverlays(p: Promise) = p.resolve(Settings.canDrawOverlays(rc))

    @ReactMethod fun openAccessibilitySettings() {
        rc.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    @ReactMethod fun requestOverlayPermission() {
        rc.startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + rc.packageName))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    @ReactMethod fun sendToBackground() { currentActivity?.moveTaskToBack(true) }

    // ---- recording -----------------------------------------------------------
    @ReactMethod fun startRecording(runLimitMs: Double) {
        RecorderOverlayService.onFinished = { list ->
            emit("MacroRecorded", mapOf("json" to Stroke.listToJson(list), "count" to list.size))
        }
        ContextCompat.startForegroundService(
            rc, Intent(rc, RecorderOverlayService::class.java)
                .putExtra(RecorderOverlayService.EXTRA_LIMIT_MS, runLimitMs.toLong())
        )
    }

    @ReactMethod fun stopRecording() { rc.stopService(Intent(rc, RecorderOverlayService::class.java)) }

    // ---- playback --------------------------------------------------------------
    @ReactMethod fun startPlayback(json: String, loops: Int, intervalMs: Double, runLimitMs: Double, p: Promise) {
        val svc = MacroAccessibilityService.instance
        if (svc == null) { p.reject("NO_SERVICE", "Accessibility service is not enabled"); return }
        val strokes = Stroke.listFromJson(json)
        ContextCompat.startForegroundService(rc, Intent(rc, AutomationForegroundService::class.java))

        svc.listener = object : MacroAccessibilityService.PlaybackListener {
            override fun onTick(remainingMs: Long) {
                NotificationHelper.update(rc, "Time left " + NotificationHelper.formatTime(remainingMs))
                emit("MacroTick", mapOf("remainingMs" to remainingMs.toDouble(), "mode" to "playing"))
            }
            override fun onFinished(reason: String) {
                rc.stopService(Intent(rc, AutomationForegroundService::class.java))
                emit("MacroFinished", mapOf("reason" to reason))
            }
        }
        svc.startPlayback(strokes, loops, intervalMs.toLong(), runLimitMs.toLong())
        p.resolve(true)
    }

    @ReactMethod fun stopPlayback() { MacroAccessibilityService.instance?.stopPlayback("user_stop") }

    // Required by NativeEventEmitter
    @ReactMethod fun addListener(eventName: String) {}
    @ReactMethod fun removeListeners(count: Int) {}
}

class MacroPackage : ReactPackage {
    override fun createNativeModules(rc: ReactApplicationContext): List<NativeModule> = listOf(MacroBridgeModule(rc))
    override fun createViewManagers(rc: ReactApplicationContext): List<ViewManager<*, *>> = emptyList()
}
