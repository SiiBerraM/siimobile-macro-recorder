package com.siimobile.macro

import org.json.JSONArray
import org.json.JSONObject

/**
 * One finger stroke = finger down -> (moves) -> finger up.
 * A tap is a stroke with a single point. Times are ms from the start of the recording.
 */
data class Stroke(val startMs: Long, val durationMs: Long, val points: List<Pair<Float, Float>>) {

    fun toJson(): JSONObject = JSONObject().apply {
        put("startMs", startMs)
        put("durationMs", durationMs)
        put("points", JSONArray().also { arr ->
            points.forEach { arr.put(JSONArray().put(it.first.toDouble()).put(it.second.toDouble())) }
        })
    }

    companion object {
        fun fromJson(o: JSONObject): Stroke {
            val arr = o.getJSONArray("points")
            val pts = (0 until arr.length()).map {
                val p = arr.getJSONArray(it)
                p.getDouble(0).toFloat() to p.getDouble(1).toFloat()
            }
            return Stroke(o.getLong("startMs"), o.getLong("durationMs"), pts)
        }

        fun listToJson(list: List<Stroke>): String =
            JSONArray().also { a -> list.forEach { a.put(it.toJson()) } }.toString()

        fun listFromJson(json: String): List<Stroke> {
            val a = JSONArray(json)
            return (0 until a.length()).map { fromJson(a.getJSONObject(it)) }
        }
    }
}
