package com.siimobile.macro

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build

/** Foreground notification shared by the recorder overlay and the playback session. */
object NotificationHelper {
    private const val CHANNEL = "siimobile_run"
    const val ID = 4201
    const val ACTION_STOP = "com.siimobile.macro.STOP_ALL"

    private fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL, "SiiMobile automation", NotificationManager.IMPORTANCE_LOW)
                )
            }
        }
    }

    fun build(ctx: Context, text: String): Notification {
        ensureChannel(ctx)
        val stop = PendingIntent.getBroadcast(
            ctx, 0,
            Intent(ACTION_STOP).setPackage(ctx.packageName),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, CHANNEL) else Notification.Builder(ctx)
        return b.setContentTitle("SiiMobile Macro Recorder")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play) // replace with your gold icon (res/drawable)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Stop", stop).build())
            .build()
    }

    fun update(ctx: Context, text: String) {
        ctx.getSystemService(NotificationManager::class.java).notify(ID, build(ctx, text))
    }

    fun startForeground(service: Service, text: String) {
        val n = build(service, text)
        if (Build.VERSION.SDK_INT >= 34) {
            service.startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            service.startForeground(ID, n)
        }
    }

    fun formatTime(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
    }
}

/** Notification "Stop" button: stops playback and recording from anywhere. */
class StopReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        MacroAccessibilityService.instance?.stopPlayback("user_stop")
        ctx.stopService(Intent(ctx, RecorderOverlayService::class.java))
        ctx.stopService(Intent(ctx, AutomationForegroundService::class.java))
    }
}

/** Keeps the process alive and the countdown notification visible during playback. */
class AutomationForegroundService : Service() {
    override fun onBind(intent: Intent?) = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        NotificationHelper.startForeground(this, "Starting…")
        return START_NOT_STICKY
    }
}
