# SiiMobile Macro Recorder & Touch Automation App

## Setup (Android)
1. npx @react-native-community/cli init SiiMobile --template react-native-template-typescript
2. npm i react-native-linear-gradient
3. Copy this folder's files over the generated project (src/, assets/, App.tsx, android/app/src/main/...).
4. Merge android/MANIFEST_ADDITIONS.xml into AndroidManifest.xml.
5. Register the package in MainApplication: add(com.siimobile.macro.MacroPackage())
6. If your applicationId is not com.siimobile, change the `package` line in the .kt files.
7. npx react-native run-android

## First run
- Allow "Display over other apps".
- Settings > Accessibility > SiiMobile Macro Recorder > turn ON (Android may ask for "Allow restricted settings" first when sideloaded).
- Pick a run time, press Record, perform gestures, tap the gold Stop pill, then Play.

## Structure
android/.../macro/  Stroke, MacroAccessibilityService, RecorderOverlayService, MacroBridgeModule, NotificationHelper
src/native/         JS wrapper for the bridge
src/hooks/          useMacroEngine (state + mandatory timer)
src/components/     GoldButton, RunTimer
src/screens/        HomeScreen
