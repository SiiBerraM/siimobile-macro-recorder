import React from 'react';
import { Image, ImageBackground, SafeAreaView, StatusBar, StyleSheet, Text, View } from 'react-native';
import { GoldButton } from '../components/GoldButton';
import { RunTimer } from '../components/RunTimer';
import { useMacroEngine } from '../hooks/useMacroEngine';
import { colors, fonts, radius } from '../theme/theme';

const STATUS_TEXT = {
  idle: 'Ready',
  recording: 'Recording in progress',
  playing: 'Automation running',
} as const;

const REASON_TEXT: Record<string, string> = {
  time_limit: 'Stopped: run time finished',
  completed: 'Finished all loops',
  user_stop: 'Stopped by you',
  interrupted: 'Interrupted by the system',
  service_disabled: 'Accessibility service was turned off',
};

export default function HomeScreen() {
  const e = useMacroEngine();
  const running = e.status !== 'idle';

  return (
    <ImageBackground source={require('../../assets/background.png')} style={styles.bg} resizeMode="cover">
      <View style={styles.scrim} />
      <SafeAreaView style={styles.root}>
        <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />

        <View style={styles.header}>
          <Image source={require('../../assets/logo.png')} style={styles.logo} resizeMode="contain" />
          <Text style={styles.title}>SiiMobile</Text>
          <Text style={styles.subtitle}>Macro Recorder & Touch Automation App</Text>
        </View>

        <View style={styles.card}>
          <View style={styles.statusRow}>
            <View style={[styles.dot, e.status === 'recording' && { backgroundColor: colors.recording }, e.status === 'playing' && { backgroundColor: colors.gold }]} />
            <Text style={styles.status}>{STATUS_TEXT[e.status]}</Text>
          </View>

          <RunTimer limitMs={e.limitMs} remainingMs={e.remainingMs} running={running} onChange={e.setLimitMs} />

          <Text style={styles.meta}>
            {e.hasMacro ? `${e.strokeCount} gestures recorded` : 'No macro yet. Press Record.'}
          </Text>
          {!!e.lastReason && !running && <Text style={styles.reason}>{REASON_TEXT[e.lastReason] ?? e.lastReason}</Text>}
        </View>

        <View style={styles.controls}>
          <GoldButton label="Record" variant="solid" onPress={e.record} disabled={running} />
          <View style={styles.row}>
            <GoldButton label="Play" onPress={e.play} disabled={running || !e.hasMacro} style={styles.half} />
            <GoldButton label="Stop" onPress={e.stop} disabled={!running} style={styles.half} />
          </View>
        </View>
      </SafeAreaView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  bg: { flex: 1, backgroundColor: colors.black },
  scrim: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.62)' }, // keeps text readable on the artwork
  root: { flex: 1, paddingHorizontal: 24, justifyContent: 'space-between' },
  header: { alignItems: 'center', paddingTop: 16 },
  logo: { width: 72, height: 72 },
  title: { marginTop: 6, fontFamily: fonts.display, fontSize: 32, color: colors.goldLight, letterSpacing: 1 },
  subtitle: { fontFamily: fonts.body, fontSize: 14, color: colors.ivory, marginTop: 2, textAlign: 'center' },
  card: {
    borderRadius: radius.lg, borderWidth: 1.5, borderColor: colors.goldDeep,
    backgroundColor: 'rgba(18,15,10,0.82)', padding: 22, gap: 16,
  },
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: 8, alignSelf: 'center' },
  dot: { width: 10, height: 10, borderRadius: 5, backgroundColor: colors.goldDeep },
  status: { fontFamily: fonts.body, fontSize: 16, color: colors.ivory },
  meta: { fontFamily: fonts.body, fontSize: 14, color: colors.muted, textAlign: 'center' },
  reason: { fontFamily: fonts.body, fontSize: 14, color: colors.goldLight, textAlign: 'center' },
  controls: { paddingBottom: 24, gap: 14 },
  row: { flexDirection: 'row', gap: 14 },
  half: { flex: 1 },
});
