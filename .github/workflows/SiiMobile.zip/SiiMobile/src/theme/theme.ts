import { Platform } from 'react-native';

/** VIP black & gold palette, taken from the P.F.I VIP Berra emblem. */
export const colors = {
  black: '#000000',
  velvet: '#120F0A',      // raised surfaces
  gold: '#D4AF37',        // primary
  goldLight: '#F3DC8A',   // highlights
  goldDeep: '#8C6D1F',    // shadows / borders
  ivory: '#F6F1E3',       // text on black
  muted: '#9A8F73',       // secondary text
  recording: '#C8372D',   // live-recording indicator only
};

export const gradients = {
  gold: [colors.goldLight, colors.gold, colors.goldDeep] as const,
  goldBorder: [colors.goldLight, colors.goldDeep, colors.gold] as const,
};

export const fonts = {
  display: Platform.select({ ios: 'Georgia', android: 'serif', default: 'serif' }),
  body: Platform.select({ ios: 'Avenir Next', android: 'sans-serif-medium', default: 'System' }),
};

export const radius = { md: 14, lg: 28, pill: 999 };
