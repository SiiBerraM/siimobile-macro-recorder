import { useCallback, useMemo, useRef, useState } from 'react';
import { PanResponder } from 'react-native';
import type { AppStatus, Macro, PlaybackOptions, TouchSample } from '../types/macro';

const MOVE_THROTTLE_MS = 16; // ~60 samples/sec is plenty for swipes

/**
 * Records touch coordinates on a surface (in-app) and replays them with timing.
 *
 * Spread `panHandlers` on the View that should capture touches.
 * `onReplaySample` is the replay hook: for now it only moves an on-screen
 * marker; in Step 3 it will call the native Android bridge (dispatchGesture).
 */
export function useTouchRecorder(onReplaySample?: (s: TouchSample) => void) {
  const [status, setStatus] = useState<AppStatus>('idle');
  const [macro, setMacro] = useState<Macro | null>(null);
  const [liveCount, setLiveCount] = useState(0);

  const startedAt = useRef(0);
  const buffer = useRef<TouchSample[]>([]);
  const lastMoveAt = useRef(0);
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);

  const push = useCallback((phase: TouchSample['phase'], x: number, y: number) => {
    const t = Date.now() - startedAt.current;
    if (phase === 'move') {
      if (t - lastMoveAt.current < MOVE_THROTTLE_MS) return;
      lastMoveAt.current = t;
    }
    buffer.current.push({ phase, x: Math.round(x), y: Math.round(y), t });
    setLiveCount(buffer.current.length);
  }, []);

  const panResponder = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => status === 'recording',
        onMoveShouldSetPanResponder: () => status === 'recording',
        onPanResponderGrant: (e) => push('down', e.nativeEvent.pageX, e.nativeEvent.pageY),
        onPanResponderMove: (e) => push('move', e.nativeEvent.pageX, e.nativeEvent.pageY),
        onPanResponderRelease: (e) => push('up', e.nativeEvent.pageX, e.nativeEvent.pageY),
        onPanResponderTerminate: (e) => push('up', e.nativeEvent.pageX, e.nativeEvent.pageY),
      }),
    [status, push],
  );

  const startRecording = useCallback(() => {
    buffer.current = [];
    lastMoveAt.current = 0;
    startedAt.current = Date.now();
    setLiveCount(0);
    setStatus('recording');
  }, []);

  const clearTimers = () => {
    timers.current.forEach(clearTimeout);
    timers.current = [];
  };

  const stop = useCallback(() => {
    if (status === 'recording') {
      const samples = buffer.current.slice();
      if (samples.length) {
        setMacro({
          id: String(Date.now()),
          name: 'Macro ' + new Date().toLocaleTimeString(),
          createdAt: Date.now(),
          durationMs: samples[samples.length - 1].t,
          samples,
        });
      }
    }
    clearTimers();
    setStatus('idle');
  }, [status]);

  const play = useCallback(
    (opts: PlaybackOptions = { loops: 1, intervalMs: 0 }) => {
      if (!macro || !macro.samples.length) return;
      setStatus('playing');

      const runLoop = (loopIndex: number) => {
        macro.samples.forEach((s) => {
          timers.current.push(setTimeout(() => onReplaySample?.(s), s.t));
        });
        timers.current.push(
          setTimeout(() => {
            const next = loopIndex + 1;
            if (opts.loops !== 0 && next >= opts.loops) {
              setStatus('idle');
            } else {
              timers.current.push(setTimeout(() => runLoop(next), opts.intervalMs));
            }
          }, macro.durationMs + 1),
        );
      };
      runLoop(0);
    },
    [macro, onReplaySample],
  );

  return {
    status,
    macro,
    liveCount,
    panHandlers: panResponder.panHandlers,
    startRecording,
    play,
    stop,
  };
}
