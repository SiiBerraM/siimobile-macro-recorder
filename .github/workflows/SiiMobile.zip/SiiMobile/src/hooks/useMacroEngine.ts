import { useCallback, useEffect, useRef, useState } from 'react';
import { Alert } from 'react-native';
import { macroEvents, MacroNative } from '../native/MacroNative';

export type EngineStatus = 'idle' | 'recording' | 'playing';

const MIN_LIMIT_MS = 10_000;          // the timer can never be zero
const DEFAULT_LIMIT_MS = 10 * 60_000; // 10 minutes

/**
 * Single source of truth for recording / playback / the mandatory run-time limit.
 * The limit is enforced natively; JS only displays it.
 */
export function useMacroEngine() {
  const [status, setStatus] = useState<EngineStatus>('idle');
  const [limitMs, setLimitMsState] = useState(DEFAULT_LIMIT_MS);
  const [remainingMs, setRemainingMs] = useState(DEFAULT_LIMIT_MS);
  const [macroJson, setMacroJson] = useState<string | null>(null);
  const [strokeCount, setStrokeCount] = useState(0);
  const [lastReason, setLastReason] = useState<string | null>(null);
  const statusRef = useRef<EngineStatus>('idle');
  statusRef.current = status;

  const setLimitMs = useCallback((ms: number) => {
    if (statusRef.current !== 'idle') return; // locked while running
    const v = Math.max(MIN_LIMIT_MS, ms);
    setLimitMsState(v);
    setRemainingMs(v);
  }, []);

  useEffect(() => {
    const subs = [
      macroEvents.addListener('MacroTick', (e: { remainingMs: number }) => setRemainingMs(e.remainingMs)),
      macroEvents.addListener('MacroRecorded', (e: { json: string; count: number }) => {
        if (e.count > 0) { setMacroJson(e.json); setStrokeCount(e.count); }
        setStatus('idle');
      }),
      macroEvents.addListener('MacroFinished', (e: { reason: string }) => {
        setLastReason(e.reason);
        setStatus('idle');
      }),
    ];
    return () => subs.forEach((s) => s.remove());
  }, []);

  // Back to the chosen limit whenever we become idle.
  useEffect(() => { if (status === 'idle') setRemainingMs(limitMs); }, [status, limitMs]);

  const ensurePermissions = useCallback(async (): Promise<boolean> => {
    if (!(await MacroNative.canDrawOverlays())) {
      Alert.alert('Display over other apps', 'Allow SiiMobile to display over other apps.', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Open settings', onPress: MacroNative.requestOverlayPermission },
      ]);
      return false;
    }
    if (!(await MacroNative.isAccessibilityEnabled())) {
      Alert.alert(
        'Accessibility service',
        'Enable "SiiMobile Macro Recorder" in Accessibility settings so taps can be replayed.',
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Open settings', onPress: MacroNative.openAccessibilitySettings },
        ],
      );
      return false;
    }
    return true;
  }, []);

  const record = useCallback(async () => {
    if (status !== 'idle' || !(await ensurePermissions())) return;
    setLastReason(null);
    setStatus('recording');
    MacroNative.startRecording(limitMs);
    MacroNative.sendToBackground(); // go to the app you want to record
  }, [status, limitMs, ensurePermissions]);

  const play = useCallback(async () => {
    if (status !== 'idle' || !macroJson || !(await ensurePermissions())) return;
    setLastReason(null);
    setStatus('playing');
    try {
      // loops = 0 -> repeat until the countdown reaches zero
      await MacroNative.startPlayback(macroJson, 0, 500, limitMs);
      MacroNative.sendToBackground();
    } catch {
      setStatus('idle');
    }
  }, [status, macroJson, limitMs, ensurePermissions]);

  const stop = useCallback(() => {
    if (statusRef.current === 'recording') MacroNative.stopRecording();
    if (statusRef.current === 'playing') MacroNative.stopPlayback();
  }, []);

  return { status, limitMs, setLimitMs, remainingMs, strokeCount, hasMacro: !!macroJson, lastReason, record, play, stop };
}

export const formatClock = (ms: number) => {
  const s = Math.max(0, Math.round(ms / 1000));
  const p = (n: number) => String(n).padStart(2, '0');
  return `${p(Math.floor(s / 3600))}:${p(Math.floor((s % 3600) / 60))}:${p(s % 60)}`;
};
