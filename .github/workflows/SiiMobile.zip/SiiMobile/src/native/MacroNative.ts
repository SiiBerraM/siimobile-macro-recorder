import { NativeEventEmitter, NativeModules } from 'react-native';

interface MacroNativeModule {
  isAccessibilityEnabled(): Promise<boolean>;
  canDrawOverlays(): Promise<boolean>;
  openAccessibilitySettings(): void;
  requestOverlayPermission(): void;
  sendToBackground(): void;
  startRecording(runLimitMs: number): void;
  stopRecording(): void;
  startPlayback(json: string, loops: number, intervalMs: number, runLimitMs: number): Promise<boolean>;
  stopPlayback(): void;
}

export const MacroNative = NativeModules.MacroNative as MacroNativeModule;
export const macroEvents = new NativeEventEmitter(NativeModules.MacroNative);
