/** One raw touch sample. `t` is ms since the recording started. */
export type TouchPhase = 'down' | 'move' | 'up';

export interface TouchSample {
  phase: TouchPhase;
  x: number; // screen X in px (pageX)
  y: number; // screen Y in px (pageY)
  t: number;
}

export interface Macro {
  id: string;
  name: string;
  createdAt: number;
  durationMs: number;
  samples: TouchSample[];
}

export interface PlaybackOptions {
  loops: number;       // 0 = infinite
  intervalMs: number;  // pause between loops (custom timer)
}

export type AppStatus = 'idle' | 'recording' | 'playing';
