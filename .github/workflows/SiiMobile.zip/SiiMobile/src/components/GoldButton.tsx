import React from 'react';
import { Pressable, StyleSheet, Text, View, ViewStyle } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { colors, fonts, gradients, radius } from '../theme/theme';

interface Props {
  label: string;
  onPress: () => void;
  icon?: React.ReactNode;
  variant?: 'solid' | 'outline';
  disabled?: boolean;
  style?: ViewStyle;
}

/** Gold-framed button. `solid` = filled gold, `outline` = gold ring on black. */
export function GoldButton({ label, onPress, icon, variant = 'outline', disabled, style }: Props) {
  const solid = variant === 'solid';
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityState={{ disabled: !!disabled }}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [{ opacity: disabled ? 0.35 : pressed ? 0.85 : 1 }, style]}
    >
      <LinearGradient colors={gradients.goldBorder} style={styles.frame}>
        {solid ? (
          <LinearGradient colors={gradients.gold} style={styles.inner}>
            {icon}
            <Text style={[styles.label, { color: colors.black }]}>{label}</Text>
          </LinearGradient>
        ) : (
          <View style={[styles.inner, { backgroundColor: colors.black }]}>
            {icon}
            <Text style={[styles.label, { color: colors.goldLight }]}>{label}</Text>
          </View>
        )}
      </LinearGradient>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  frame: { borderRadius: radius.pill, padding: 1.5 },
  inner: {
    minHeight: 56,
    borderRadius: radius.pill,
    paddingHorizontal: 28,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
  },
  label: { fontFamily: fonts.body, fontSize: 17, fontWeight: '700', letterSpacing: 0.6 },
});
