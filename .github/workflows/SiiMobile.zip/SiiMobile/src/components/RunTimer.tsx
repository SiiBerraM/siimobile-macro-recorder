import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { formatClock } from '../hooks/useMacroEngine';
import { colors, fonts, radius } from '../theme/theme';

interface Props {
  limitMs: number;
  remainingMs: number;
  running: boolean;
  onChange: (ms: number) => void;
}

const PRESETS = [
  { label: '5 min', ms: 5 * 60_000 },
  { label: '15 min', ms: 15 * 60_000 },
  { label: '30 min', ms: 30 * 60_000 },
  { label: '1 h', ms: 60 * 60_000 },
];

/** Mandatory run-time control. Locked (read-only countdown) while recording or playing. */
export function RunTimer({ limitMs, remainingMs, running, onChange }: Props) {
  const progress = running ? Math.min(1, Math.max(0, remainingMs / limitMs)) : 1;
  const step = (d: number) => onChange(limitMs + d);

  return (
    <View style={styles.wrap}>
      <Text style={styles.caption}>{running ? 'Time left' : 'Run time'}</Text>

      <View style={styles.clockRow}>
        <Pressable accessibilityLabel="Remove one minute" disabled={running} onPress={() => step(-60_000)} style={[styles.step, running && styles.off]}>
          <Text style={styles.stepText}>−</Text>
        </Pressable>
        <Text style={styles.clock}>{formatClock(running ? remainingMs : limitMs)}</Text>
        <Pressable accessibilityLabel="Add one minute" disabled={running} onPress={() => step(60_000)} style={[styles.step, running && styles.off]}>
          <Text style={styles.stepText}>+</Text>
        </Pressable>
      </View>

      <View style={styles.track}><View style={[styles.fill, { width: `${progress * 100}%` }]} /></View>

      {!running && (
        <View style={styles.presets}>
          {PRESETS.map((p) => (
            <Pressable key={p.label} onPress={() => onChange(p.ms)} style={[styles.chip, limitMs === p.ms && styles.chipOn]}>
              <Text style={[styles.chipText, limitMs === p.ms && { color: colors.black }]}>{p.label}</Text>
            </Pressable>
          ))}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { alignItems: 'center' },
  caption: { fontFamily: fonts.body, fontSize: 14, color: colors.muted },
  clockRow: { flexDirection: 'row', alignItems: 'center', gap: 18, marginTop: 6 },
  clock: { fontFamily: fonts.display, fontSize: 52, color: colors.gold, fontVariant: ['tabular-nums'] },
  step: { width: 44, height: 44, borderRadius: 22, borderWidth: 1.5, borderColor: colors.gold, alignItems: 'center', justifyContent: 'center' },
  off: { opacity: 0.25 },
  stepText: { color: colors.goldLight, fontSize: 26, lineHeight: 28 },
  track: { alignSelf: 'stretch', height: 4, borderRadius: 2, backgroundColor: colors.velvet, marginTop: 12, overflow: 'hidden' },
  fill: { height: 4, backgroundColor: colors.gold },
  presets: { flexDirection: 'row', gap: 10, marginTop: 14 },
  chip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: radius.pill, borderWidth: 1, borderColor: colors.goldDeep },
  chipOn: { backgroundColor: colors.gold, borderColor: colors.gold },
  chipText: { fontFamily: fonts.body, fontSize: 14, color: colors.goldLight },
});
